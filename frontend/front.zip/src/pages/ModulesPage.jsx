import { useParams } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import {
  BookOpen, ChevronRight, FlaskConical, BookMarked,
  Layers, CheckCircle, Lock, Send, Clock, XCircle,
} from "lucide-react";
import { useState } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";

import { useAuth } from "../context/AuthContext";
import { apiRequest } from "../lib/api";
import { queryKeys } from "../lib/queryKeys";

/* ─── API helpers ─── */
async function fetchProgress(token) {
  const r = await apiRequest("/api/intern/progress/", { token });
  return r.data;
}
async function fetchUnlocks(token) {
  const r = await apiRequest("/api/intern/unlocks/", { token });
  return r.data;
}

/* ─── Concept tag helpers ─── */
function getConceptTags(concept) {
  const c = (concept || "").toLowerCase();
  const tags = [];
  if (c.includes("theory") || c === "both") tags.push("theory");
  if (c.includes("practical") || c === "both") tags.push("practical");
  return tags.length ? tags : ["theory"];
}

function getTopicProgress(progressList, moduleId, topicId) {
  return progressList?.find((p) => p.module_id === moduleId && p.topic_id === topicId) || null;
}

function isTopicFullyApproved(progress, concept) {
  if (!progress) return false;
  const tags = getConceptTags(concept);
  if (tags.includes("theory") && !progress.theory_approved) return false;
  if (tags.includes("practical") && !progress.practical_approved) return false;
  return true;
}

function isTopicFullySubmitted(progress, concept) {
  if (!progress) return false;
  const tags = getConceptTags(concept);
  if (tags.includes("theory") && !progress.theory_submitted) return false;
  if (tags.includes("practical") && !progress.practical_submitted) return false;
  return true;
}

function isModuleCompleteForIntern(mod, progressList) {
  if (!mod.topics || mod.topics.length === 0) return false;
  return mod.topics.every((t) => {
    const p = getTopicProgress(progressList, mod.id, t.id);
    return isTopicFullyApproved(p, t.concept);
  });
}

function getModuleLockStatus(mod, modIndex, unlocks) {
  if (modIndex === 0) return "unlocked";
  const unlockDoc = unlocks?.find((u) => u.module_id === mod.id);
  if (unlockDoc?.status === "unlocked") return "unlocked";
  if (unlockDoc?.status === "pending") return "pending";
  return "locked";
}

/* ─── Breadcrumb ─── */
function Breadcrumb({ items }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "0.84rem", color: "var(--text-soft)", flexWrap: "wrap", marginBottom: "4px" }}>
      {items.map((item, i) => (
        <span key={i} style={{ display: "flex", alignItems: "center", gap: "6px" }}>
          {i > 0 && <ChevronRight size={13} />}
          {item.to ? (
            <Link to={item.to} style={{ color: "var(--text-soft)", textDecoration: "none" }}>
              {item.label}
            </Link>
          ) : (
            <span style={{ color: "var(--text)" }}>{item.label}</span>
          )}
        </span>
      ))}
    </div>
  );
}

/* ─── Topic Detail Page ─── */
function TopicDetailPage({ mod, topic, modIndex, progressList, unlocks, allModules, role }) {
  const { token } = useAuth();
  const queryClient = useQueryClient();
  const [feedback, setFeedback] = useState("");

  const tags = getConceptTags(topic.concept);
  const progress = getTopicProgress(progressList, mod.id, topic.id);
  const fullyApproved = isTopicFullyApproved(progress, topic.concept);
  const fullySubmitted = isTopicFullySubmitted(progress, topic.concept);
  const modComplete = isModuleCompleteForIntern(mod, progressList);

  const lockStatus = role === "intern"
    ? getModuleLockStatus(mod, modIndex, unlocks)
    : "unlocked";

  const submitMutation = useMutation({
    mutationFn: ({ moduleId, topicId, completionType }) =>
      apiRequest("/api/intern/progress/submit/", {
        method: "POST",
        token,
        body: { module_id: moduleId, topic_id: topicId, completion_type: completionType },
      }),
    onSuccess: () => {
      setFeedback("Submitted for manager approval! You'll be notified when approved.");
      queryClient.invalidateQueries({ queryKey: queryKeys.topicProgress(token) });
      setTimeout(() => setFeedback(""), 4000);
    },
    onError: (err) => {
      setFeedback(err.message || "Submission failed.");
      setTimeout(() => setFeedback(""), 4000);
    },
  });

  const unlockMutation = useMutation({
    mutationFn: () =>
      apiRequest("/api/intern/unlocks/request/", {
        method: "POST",
        token,
        body: { module_id: allModules[modIndex + 1]?.id },
      }),
    onSuccess: () => {
      setFeedback("Unlock request sent to manager!");
      queryClient.invalidateQueries({ queryKey: queryKeys.moduleUnlocks(token) });
      setTimeout(() => setFeedback(""), 3000);
    },
    onError: (err) => {
      setFeedback(err.message || "Request failed.");
      setTimeout(() => setFeedback(""), 4000);
    },
  });

  if (lockStatus === "locked") {
    return (
      <div className="page-stack">
        <Breadcrumb items={[{ label: "Modules", to: "/modules" }, { label: mod.label, to: `/modules/${mod.id}` }, { label: topic.label }]} />
        <div className="hero-banner" style={{ flexDirection: "column", alignItems: "flex-start", gap: "10px" }}>
          <div>
            <span className="eyebrow">Topic</span>
            <h2 style={{ margin: "6px 0 4px" }}>{topic.label}</h2>
          </div>
          <span className="status-pill status-pill--neutral"><Lock size={13} />&nbsp;Module Locked</span>
        </div>
        <div className="state-block">
          <Lock size={32} style={{ opacity: 0.3, marginBottom: "12px" }} />
          <p>This module is locked. Complete the previous module first to unlock it.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page-stack">
      <Breadcrumb items={[{ label: "Modules", to: "/modules" }, { label: mod.label, to: `/modules/${mod.id}` }, { label: topic.label }]} />

      <div className="hero-banner" style={{ flexDirection: "column", alignItems: "flex-start", gap: "12px" }}>
        <div>
          <span className="eyebrow">Topic · {mod.label}</span>
          <h2 style={{ margin: "6px 0 8px" }}>{topic.label}</h2>
        </div>
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          {tags.map((tag) => (
            <span key={tag} className={`status-pill ${tag === "practical" ? "status-pill--approved" : "status-pill--pending"}`}>
              {tag === "practical" ? <FlaskConical size={13} /> : <BookMarked size={13} />}&nbsp;{tag === "theory" ? "Theory" : "Practical"}
            </span>
          ))}
          {fullyApproved && <span className="status-pill status-pill--approved"><CheckCircle size={13} />&nbsp;Fully Approved</span>}
          {!fullyApproved && fullySubmitted && <span className="status-pill status-pill--pending"><Clock size={13} />&nbsp;Pending Approval</span>}
        </div>
      </div>

      {feedback && (
        <div className={`form-message ${feedback.toLowerCase().includes("fail") || feedback.toLowerCase().includes("error") ? "is-error" : "is-success"}`}>
          {feedback}
        </div>
      )}

      {/* Content panel */}
      <div className="panel">
        <div className="panel__header">
          <div><h3>Learning Content</h3><p>Study material for this topic.</p></div>
        </div>
        <div className="state-block" style={{ background: "rgba(34,167,200,0.04)", borderStyle: "dashed" }}>
          <BookOpen size={32} style={{ opacity: 0.3, marginBottom: "12px" }} />
          <p style={{ margin: 0 }}>Content for <strong>{topic.label}</strong> will appear here.</p>
        </div>
      </div>

      {/* Subtopics */}
      {topic.subtopics?.length > 0 && (
        <div className="panel">
          <div className="panel__header"><div><h3>Subtopics</h3></div></div>
          <div className="list-stack">
            {topic.subtopics.map((sub, i) => (
              <div key={i} className="entity-card" style={{ padding: "14px 18px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                  <span style={{ width: "26px", height: "26px", borderRadius: "8px", background: "var(--accent-gradient)", display: "grid", placeItems: "center", color: "var(--midnight)", fontSize: "0.72rem", fontWeight: 800, flexShrink: 0 }}>{i + 1}</span>
                  <span>{sub}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Chapters */}
      {topic.chapters?.length > 0 && (
        <div className="panel">
          <div className="panel__header"><div><h3>Chapters</h3></div></div>
          <div className="list-stack">
            {topic.chapters.map((ch, i) => {
              const chLabel = typeof ch === "string" ? ch : ch.label;
              return (
                <Link
                  key={i}
                  to={`/modules/${mod.id}/${topic.id}/${i}`}
                  className="entity-card"
                  style={{ padding: "14px 18px", display: "flex", alignItems: "center", gap: "12px", textDecoration: "none", color: "inherit" }}
                >
                  <span style={{ width: "26px", height: "26px", borderRadius: "8px", background: "var(--accent-gradient)", display: "grid", placeItems: "center", color: "var(--midnight)", fontSize: "0.72rem", fontWeight: 800, flexShrink: 0 }}>{i + 1}</span>
                  <span style={{ flex: 1 }}>{chLabel}</span>
                  <ChevronRight size={14} style={{ color: "var(--text-soft)" }} />
                </Link>
              );
            })}
          </div>
        </div>
      )}

      {/* Submit section — intern only */}
      {role === "intern" && !fullyApproved && (
        <div className="panel">
          <div className="panel__header">
            <div>
              <h3>Submit for Approval</h3>
              <p>Once you've completed this topic, submit it. Your manager will review and approve it, and you'll get a notification.</p>
            </div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            {tags.map((part) => {
              const submitted = progress?.[`${part}_submitted`];
              const approved = progress?.[`${part}_approved`];
              if (approved) {
                return (
                  <div key={part} style={{ display: "flex", alignItems: "center", gap: "10px", padding: "12px 16px", borderRadius: "10px", background: "rgba(33,181,84,0.08)", border: "1px solid rgba(33,181,84,0.25)" }}>
                    {part === "practical" ? <FlaskConical size={15} /> : <BookMarked size={15} />}
                    <span style={{ fontWeight: 600 }}>{part === "theory" ? "Theory" : "Practical"}</span>
                    <CheckCircle size={15} style={{ color: "#21b554", marginLeft: "auto" }} />
                    <span style={{ fontSize: "0.84rem", color: "#21b554" }}>Approved</span>
                  </div>
                );
              }
              if (submitted) {
                return (
                  <div key={part} style={{ display: "flex", alignItems: "center", gap: "10px", padding: "12px 16px", borderRadius: "10px", background: "rgba(34,167,200,0.06)", border: "1px solid rgba(34,167,200,0.2)" }}>
                    {part === "practical" ? <FlaskConical size={15} /> : <BookMarked size={15} />}
                    <span style={{ fontWeight: 600 }}>{part === "theory" ? "Theory" : "Practical"}</span>
                    <Clock size={15} style={{ color: "var(--accent)", marginLeft: "auto" }} />
                    <span style={{ fontSize: "0.84rem", color: "var(--accent)" }}>Awaiting approval</span>
                  </div>
                );
              }
              return (
                <button
                  key={part}
                  type="button"
                  className="primary-button"
                  style={{ gap: "10px", justifyContent: "flex-start" }}
                  disabled={submitMutation.isPending}
                  onClick={() => {
                    setFeedback("");
                    submitMutation.mutate({ moduleId: mod.id, topicId: topic.id, completionType: part });
                  }}
                >
                  {part === "practical" ? <FlaskConical size={15} /> : <BookMarked size={15} />}
                  Submit {part === "theory" ? "Theory" : "Practical"} for Approval
                  <Send size={14} style={{ marginLeft: "auto" }} />
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Fully approved summary for intern */}
      {role === "intern" && fullyApproved && (
        <div className="panel">
          <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "4px 0" }}>
            <CheckCircle size={22} style={{ color: "#21b554" }} />
            <div>
              <strong>Topic Complete!</strong>
              <p style={{ margin: "2px 0 0", fontSize: "0.85rem", color: "var(--text-soft)" }}>All parts approved by your manager.</p>
            </div>
          </div>
        </div>
      )}

      {/* Manager status view */}
      {role !== "intern" && (
        <div className="panel">
          <div className="panel__header"><div><h3>Topic Submission Status</h3></div></div>
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            {tags.map((part) => {
              const approved = progress?.[`${part}_approved`];
              const submitted = progress?.[`${part}_submitted`];
              return (
                <div key={part} style={{ display: "flex", alignItems: "center", gap: "10px", padding: "12px 16px", borderRadius: "10px", border: "1px solid var(--border)", background: "var(--surface)" }}>
                  {part === "practical" ? <FlaskConical size={15} /> : <BookMarked size={15} />}
                  <span style={{ fontWeight: 600 }}>{part === "theory" ? "Theory" : "Practical"}</span>
                  <span style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: "6px" }}>
                    {approved
                      ? <><CheckCircle size={15} style={{ color: "#21b554" }} /><span style={{ color: "#21b554", fontSize: "0.84rem" }}>Approved</span></>
                      : submitted
                        ? <><Clock size={15} style={{ color: "var(--accent)" }} /><span style={{ color: "var(--accent)", fontSize: "0.84rem" }}>Submitted — pending review</span></>
                        : <><XCircle size={15} style={{ opacity: 0.35 }} /><span style={{ opacity: 0.5, fontSize: "0.84rem" }}>Not submitted yet</span></>}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Module complete → request next unlock */}
      {role === "intern" && modComplete && modIndex < allModules.length - 1 && (() => {
        const nextMod = allModules[modIndex + 1];
        const nextUnlock = unlocks?.find((u) => u.module_id === nextMod.id);
        if (!nextUnlock || nextUnlock.status === "locked") {
          return (
            <div className="panel">
              <div className="panel__header"><div><h3>Module Complete 🎉</h3><p>All topics approved! You can now request the next module.</p></div></div>
              <button
                type="button"
                className="primary-button"
                style={{ width: "fit-content" }}
                disabled={unlockMutation.isPending}
                onClick={() => unlockMutation.mutate()}
              >
                <Send size={14} />&nbsp;
                {unlockMutation.isPending ? "Requesting..." : `Request unlock: ${nextMod.label}`}
              </button>
            </div>
          );
        }
        if (nextUnlock.status === "pending") {
          return (
            <div className="panel">
              <div className="panel__header"><div><h3>Module Complete 🎉</h3><p>Unlock request for the next module is pending manager approval.</p></div></div>
              <span className="status-pill status-pill--pending"><Clock size={13} />&nbsp;Unlock Pending Approval</span>
            </div>
          );
        }
        return null;
      })()}
    </div>
  );
}

/* ─── Module Topics Page (list of topics in a module) ─── */
function ModuleTopicsPage({ mod, modIndex, progressList, unlocks, role }) {
  const lockStatus = role === "intern"
    ? getModuleLockStatus(mod, modIndex, unlocks)
    : "unlocked";

  const modComplete = isModuleCompleteForIntern(mod, progressList);
  const approvedCount = (mod.topics || []).filter((t) => {
    const p = getTopicProgress(progressList, mod.id, t.id);
    return isTopicFullyApproved(p, t.concept);
  }).length;

  if (lockStatus === "locked") {
    return (
      <div className="page-stack">
        <Breadcrumb items={[{ label: "Modules", to: "/modules" }, { label: mod.label }]} />
        <div className="hero-banner" style={{ flexDirection: "column", alignItems: "flex-start", gap: "10px" }}>
          <div><span className="eyebrow">Module</span><h2 style={{ margin: "6px 0 4px" }}>{mod.label}</h2></div>
          <span className="status-pill status-pill--neutral"><Lock size={13} />&nbsp;Locked</span>
        </div>
        <div className="state-block">
          <Lock size={32} style={{ opacity: 0.3, marginBottom: "12px" }} />
          <p>This module is locked. Complete and get all topics in the previous module approved to unlock it.</p>
        </div>
      </div>
    );
  }

  if (lockStatus === "pending") {
    return (
      <div className="page-stack">
        <Breadcrumb items={[{ label: "Modules", to: "/modules" }, { label: mod.label }]} />
        <div className="hero-banner" style={{ flexDirection: "column", alignItems: "flex-start", gap: "10px" }}>
          <div><span className="eyebrow">Module</span><h2 style={{ margin: "6px 0 4px" }}>{mod.label}</h2></div>
          <span className="status-pill status-pill--pending"><Clock size={13} />&nbsp;Unlock Pending Approval</span>
        </div>
        <div className="state-block">
          <Clock size={32} style={{ opacity: 0.3, marginBottom: "12px" }} />
          <p>Your unlock request is waiting for manager approval. You'll be notified once approved.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page-stack">
      <Breadcrumb items={[{ label: "Modules", to: "/modules" }, { label: mod.label }]} />

      <div className="hero-banner" style={{ flexDirection: "column", alignItems: "flex-start", gap: "12px" }}>
        <div>
          <span className="eyebrow">Module</span>
          <h2 style={{ margin: "6px 0 4px" }}>{mod.label}</h2>
          <p style={{ margin: 0, color: "var(--text-soft)" }}>{mod.topics.length} topics · {approvedCount} approved</p>
        </div>
        {modComplete && (
          <span className="status-pill status-pill--approved" style={{ fontSize: "0.84rem" }}>
            <CheckCircle size={14} />&nbsp;Module Complete
          </span>
        )}
        {mod.topics.length > 0 && (
          <div className="module-progress" style={{ width: "100%", maxWidth: "340px" }}>
            <div className="module-progress__bar module-progress__bar--large">
              <div className="module-progress__fill" style={{ width: `${Math.round((approvedCount / mod.topics.length) * 100)}%` }} />
            </div>
            <span className="module-progress__label">{approvedCount}/{mod.topics.length} topics approved</span>
          </div>
        )}
      </div>

      <div className="list-stack">
        {mod.topics.map((topic) => {
          const tags = getConceptTags(topic.concept);
          const progress = getTopicProgress(progressList, mod.id, topic.id);
          const topicDone = isTopicFullyApproved(progress, topic.concept);
          const topicSubmitted = isTopicFullySubmitted(progress, topic.concept);

          return (
            <Link
              key={topic.id}
              to={`/modules/${mod.id}/${topic.id}`}
              className="entity-card"
              style={{ textDecoration: "none", color: "inherit", display: "block" }}
            >
              <div style={{ display: "flex", alignItems: "flex-start", gap: "12px" }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
                    <strong>{topic.label}</strong>
                    {topicDone && <CheckCircle size={15} style={{ color: "#21b554", flexShrink: 0 }} />}
                    {!topicDone && topicSubmitted && <Clock size={14} style={{ color: "var(--accent)", flexShrink: 0 }} />}
                  </div>
                  <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                    {tags.map((t) => (
                      <span key={t} className={`status-pill ${t === "practical" ? "status-pill--approved" : "status-pill--pending"}`} style={{ fontSize: "0.72rem", padding: "3px 8px" }}>
                        {t === "practical" ? <FlaskConical size={11} /> : <BookMarked size={11} />}&nbsp;{t === "theory" ? "Theory" : "Practical"}
                      </span>
                    ))}
                    {topic.chapters?.length > 0 && (
                      <span className="status-pill status-pill--neutral" style={{ fontSize: "0.72rem", padding: "3px 8px" }}>
                        <Layers size={11} />&nbsp;{topic.chapters.length} chapter{topic.chapters.length > 1 ? "s" : ""}
                      </span>
                    )}
                    {topicDone && <span className="status-pill status-pill--approved" style={{ fontSize: "0.72rem", padding: "3px 8px" }}>Approved</span>}
                    {!topicDone && topicSubmitted && <span className="status-pill status-pill--pending" style={{ fontSize: "0.72rem", padding: "3px 8px" }}>Pending review</span>}
                  </div>
                </div>
                <ChevronRight size={16} style={{ color: "var(--text-soft)", flexShrink: 0, marginTop: "2px" }} />
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Chapter detail view ─── */
function ChapterDetail({ chapter, mod, topic }) {
  const tags = getConceptTags(chapter.concept);
  const [activeTab, setActiveTab] = useState(tags[0] || "theory");

  return (
    <div className="page-stack">
      <Breadcrumb items={[
        { label: "Modules", to: "/modules" },
        { label: mod.label, to: `/modules/${mod.id}` },
        { label: topic.label, to: `/modules/${mod.id}/${topic.id}` },
        { label: chapter.label },
      ]} />

      <div className="hero-banner" style={{ flexDirection: "column", alignItems: "flex-start", gap: "12px" }}>
        <div>
          <span className="eyebrow">Chapter</span>
          <h2 style={{ margin: "6px 0 8px" }}>{chapter.label}</h2>
        </div>
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          {tags.map((tag) => (
            <span key={tag} className={`status-pill ${tag === "practical" ? "status-pill--approved" : "status-pill--pending"}`}>
              {tag === "practical" ? <FlaskConical size={13} /> : <BookMarked size={13} />}&nbsp;{tag === "theory" ? "Theory" : "Practical"}
            </span>
          ))}
          {chapter.subtopics?.length > 0 && (
            <span className="status-pill status-pill--neutral">
              <Layers size={13} />&nbsp;{chapter.subtopics.length} subtopic{chapter.subtopics.length > 1 ? "s" : ""}
            </span>
          )}
        </div>
      </div>

      {tags.length > 1 && (
        <div style={{ display: "flex", gap: "8px" }}>
          {tags.map((tab) => (
            <button key={tab} type="button" className={activeTab === tab ? "primary-button" : "ghost-button"} style={{ padding: "10px 20px" }} onClick={() => setActiveTab(tab)}>
              {tab === "practical" ? <FlaskConical size={15} /> : <BookMarked size={15} />}&nbsp;{tab === "theory" ? "Theory" : "Practical"}
            </button>
          ))}
        </div>
      )}

      <div className="panel">
        <div className="panel__header">
          <div><h3>{activeTab === "theory" ? "Theory" : "Practical"} Content</h3><p>Study material for this chapter.</p></div>
        </div>
        <div className="state-block" style={{ background: "rgba(34,167,200,0.04)", borderStyle: "dashed" }}>
          <BookOpen size={32} style={{ opacity: 0.3, marginBottom: "12px" }} />
          <p style={{ margin: 0 }}>{activeTab === "theory" ? "Theory" : "Practical"} content for <strong>{chapter.label}</strong> is not yet available.</p>
        </div>
      </div>

      {chapter.subtopics?.length > 0 && (
        <div className="panel">
          <div className="panel__header"><div><h3>Subtopics</h3></div></div>
          <div className="list-stack">
            {chapter.subtopics.map((sub, i) => (
              <div key={i} className="entity-card" style={{ padding: "14px 18px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                  <span style={{ width: "26px", height: "26px", borderRadius: "8px", background: "var(--accent-gradient)", display: "grid", placeItems: "center", color: "var(--midnight)", fontSize: "0.72rem", fontWeight: 800, flexShrink: 0 }}>{i + 1}</span>
                  <span>{sub}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {chapter.refs?.length > 0 && (
        <div className="panel">
          <div className="panel__header"><div><h3>Reference Links</h3></div></div>
          <div className="list-stack">
            {chapter.refs.map((ref, i) => (
              <a key={i} href={ref} target="_blank" rel="noreferrer" className="entity-card" style={{ padding: "12px 16px", display: "block", wordBreak: "break-all", fontSize: "0.86rem" }}>{ref}</a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Modules Landing (list of all modules as clickable cards) ─── */
function ModulesLanding({ allModules, progressList, unlocks, role }) {
  const totalTopics = allModules.reduce((s, m) => s + (m.topics?.length || 0), 0);
  const approvedTopics = allModules.reduce((s, m) => {
    return s + (m.topics || []).filter((t) => {
      const p = getTopicProgress(progressList, m.id, t.id);
      return isTopicFullyApproved(p, t.concept);
    }).length;
  }, 0);
  const pct = totalTopics === 0 ? 0 : Math.round((approvedTopics / totalTopics) * 100);

  return (
    <div className="page-stack">
      <div className="hero-banner" style={{ flexDirection: "column", alignItems: "flex-start", gap: "14px" }}>
        <div>
          <span className="eyebrow">Learning Modules</span>
          <h2 style={{ margin: "6px 0 4px" }}>Modules</h2>
          <p>Select a module below to begin learning.</p>
        </div>
        {allModules.length > 0 && (
          <div className="module-progress" style={{ width: "100%", maxWidth: "340px" }}>
            <div className="module-progress__bar module-progress__bar--large">
              <div className="module-progress__fill" style={{ width: `${pct}%` }} />
            </div>
            <span className="module-progress__label">{approvedTopics}/{totalTopics} topics approved</span>
          </div>
        )}
      </div>

      <div className="list-stack">
        {allModules.map((mod, idx) => {
          const lockStatus = role === "intern"
            ? getModuleLockStatus(mod, idx, unlocks)
            : "unlocked";
          const complete = isModuleCompleteForIntern(mod, progressList);
          const approvedCount = (mod.topics || []).filter((t) => {
            const p = getTopicProgress(progressList, mod.id, t.id);
            return isTopicFullyApproved(p, t.concept);
          }).length;
          const isLocked = lockStatus === "locked";
          const isPending = lockStatus === "pending";

          const content = (
            <div style={{ display: "flex", alignItems: "flex-start", gap: "14px" }}>
              <div style={{ width: "40px", height: "40px", borderRadius: "12px", background: "var(--accent-gradient)", display: "grid", placeItems: "center", color: "var(--midnight)", fontWeight: 800, fontSize: "1rem", flexShrink: 0 }}>
                {idx + 1}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
                  <strong style={{ fontSize: "1rem" }}>{mod.label}</strong>
                  {complete && <CheckCircle size={15} style={{ color: "#21b554", flexShrink: 0 }} />}
                  {isLocked && <Lock size={14} style={{ opacity: 0.5, flexShrink: 0 }} />}
                  {isPending && <Clock size={14} style={{ color: "var(--accent)", flexShrink: 0 }} />}
                </div>
                <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                  <span className="status-pill status-pill--neutral" style={{ fontSize: "0.75rem" }}>
                    <BookOpen size={11} />&nbsp;{mod.topics.length} topics
                  </span>
                  {complete && <span className="status-pill status-pill--approved" style={{ fontSize: "0.75rem" }}>Complete</span>}
                  {isPending && <span className="status-pill status-pill--pending" style={{ fontSize: "0.75rem" }}>Unlock pending</span>}
                  {isLocked && <span className="status-pill status-pill--neutral" style={{ fontSize: "0.75rem" }}>Locked</span>}
                  {!isLocked && !isPending && mod.topics.length > 0 && (
                    <span className="status-pill status-pill--neutral" style={{ fontSize: "0.75rem" }}>
                      {approvedCount}/{mod.topics.length} approved
                    </span>
                  )}
                </div>
              </div>
              {!isLocked && <ChevronRight size={16} style={{ color: "var(--text-soft)", flexShrink: 0, marginTop: "4px" }} />}
            </div>
          );

          if (isLocked) {
            return (
              <div key={mod.id} className="entity-card" style={{ opacity: 0.55 }}>
                {content}
              </div>
            );
          }

          return (
            <Link
              key={mod.id}
              to={`/modules/${mod.id}`}
              className="entity-card"
              style={{ textDecoration: "none", color: "inherit", display: "block" }}
            >
              {content}
            </Link>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Main ─── */
export function ModulesPage() {
  const { token, user } = useAuth();
  const params = useParams({ strict: false });
  const { moduleId, topicId, chapterIdx } = params;

  const { data: allModules = [] } = useQuery({
    queryKey: queryKeys.modules(token),
    queryFn: () => apiRequest("/api/modules/", { token }).then((r) => r.data),
    enabled: !!token,
  });

  const { data: progressList = [] } = useQuery({
    queryKey: queryKeys.topicProgress(token),
    queryFn: () => fetchProgress(token),
    enabled: !!token,
  });

  const { data: unlocks = [] } = useQuery({
    queryKey: queryKeys.moduleUnlocks(token),
    queryFn: () => fetchUnlocks(token),
    enabled: !!token,
  });

  const role = user?.role;
  const mod = allModules.find((m) => m.id === moduleId);

  // /modules — show modules list
  if (!mod) {
    return <ModulesLanding allModules={allModules} progressList={progressList} unlocks={unlocks} role={role} />;
  }

  const modIndex = allModules.findIndex((m) => m.id === moduleId);
  const topic = mod.topics.find((t) => t.id === topicId);

  // /modules/:moduleId — show topics list in this module
  if (!topic) {
    return (
      <ModuleTopicsPage
        mod={mod}
        modIndex={modIndex}
        progressList={progressList}
        unlocks={unlocks}
        role={role}
      />
    );
  }

  // /modules/:moduleId/:topicId/:chapterIdx — chapter detail
  if (chapterIdx !== undefined && topic.chapters) {
    const idx = parseInt(chapterIdx, 10);
    const rawChapter = topic.chapters[idx];
    if (rawChapter !== undefined) {
      const chapter = typeof rawChapter === "string"
        ? { label: rawChapter, concept: topic.concept || "Theory", subtopics: [], refs: [] }
        : rawChapter;
      return <ChapterDetail chapter={chapter} mod={mod} topic={topic} />;
    }
  }

  // /modules/:moduleId/:topicId — topic detail with submit button
  return (
    <TopicDetailPage
      mod={mod}
      topic={topic}
      modIndex={modIndex}
      progressList={progressList}
      unlocks={unlocks}
      allModules={allModules}
      role={role}
    />
  );
}
