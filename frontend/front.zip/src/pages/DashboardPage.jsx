import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";

import { Panel } from "../components/Panel";
import { RatingStars } from "../components/RatingStars";
import { StatCard } from "../components/StatCard";
import { useAuth } from "../context/AuthContext";
import { apiRequest } from "../lib/api";
import { queryKeys } from "../lib/queryKeys";
import { formatDate, titleCase } from "../lib/formatters";

function LoadingState() {
  return <div className="state-block">Loading dashboard...</div>;
}

function ErrorState({ error, onRetry }) {
  return (
    <div className="state-block state-block--error">
      <p>{error}</p>
      <button type="button" className="ghost-button" onClick={onRetry}>
        Try again
      </button>
    </div>
  );
}

function ReviewSummaryCard({ reviewSummary }) {
  return (
    <div className="review-summary">
      <div>
        <span>Communication</span>
        <RatingStars value={reviewSummary.communication_rating_average} />
      </div>
      <div>
        <span>Technical</span>
        <RatingStars value={reviewSummary.technical_rating_average} />
      </div>
      <div>
        <span>Overall</span>
        <RatingStars value={reviewSummary.overall_rating_average} />
      </div>
    </div>
  );
}

export function DashboardPage() {
  const { token, user } = useAuth();

  const { data, error, isLoading, refetch } = useQuery({
    queryKey: queryKeys.dashboard(token),
    queryFn: () =>
      apiRequest("/api/dashboard/overview/", { token }).then((r) => r.data),
  });

  if (isLoading) return <LoadingState />;
  if (error) return <ErrorState error={error.message} onRetry={refetch} />;

  const statsEntries = Object.entries(data.stats || {});

  return (
    <div className="page-stack">
      <section className="hero-banner">
        <div>
          <span className="eyebrow">Role-specific command center</span>
          <h2>{titleCase(user.role)} dashboard for Cyber Vidya</h2>
          <p>
            Track the latest approvals, reviews, activity, and profile health from one focused workspace.
          </p>
        </div>
        <div className="hero-banner__meta">
          <strong>{data.user_profile?.name}</strong>
          <span>{titleCase(data.role)}</span>
        </div>
      </section>

      <section className="stat-grid">
        {statsEntries.map(([key, value]) => (
          <StatCard key={key} title={titleCase(key)} value={value} />
        ))}
      </section>

      {data.role === "intern" ? (
        <>
          <Panel title="My review snapshot" subtitle="Your latest communication and technical standing">
            <ReviewSummaryCard reviewSummary={data.review_summary} />
          </Panel>

          <div className="two-column">
            <Panel title="My reviews" subtitle="What managers have shared about your growth">
              <div className="list-stack">
                {data.my_reviews?.map((review) => (
                  <article key={review.id} className="entity-card">
                    <div className="entity-card__top">
                      <div>
                        <strong>{review.manager_name}</strong>
                        <span>{formatDate(review.updated_at)}</span>
                      </div>
                      <RatingStars value={review.average_rating} />
                    </div>
                    <div className="entity-card__details">
                      <p><strong>Communication:</strong> {review.communication_comment || "Pending"}</p>
                      <p><strong>Technical:</strong> {review.technical_comment || "Pending"}</p>
                    </div>
                  </article>
                ))}
              </div>
            </Panel>

            <Panel title="My approvals" subtitle="Track your permission requests">
              <div className="list-stack">
                {data.my_approvals?.map((approval) => (
                  <article key={approval.id} className="entity-card">
                    <div className="entity-card__top">
                      <div>
                        <strong>{titleCase(approval.request_type)} permission</strong>
                        <span>{formatDate(approval.created_at)}</span>
                      </div>
                      <span className={`status-pill status-pill--${approval.status}`}>{titleCase(approval.status)}</span>
                    </div>
                    <p>{approval.reason}</p>
                  </article>
                ))}
              </div>
            </Panel>
          </div>
        </>
      ) : (
        <>
          <div className="two-column two-column--wide">
            <Panel
              title="Intern overview"
              subtitle="Profiles, permissions, and review standing"
              action={<Link className="text-link" to="/interns">Open directory</Link>}
            >
              <div className="card-grid">
                {data.interns?.slice(0, 6).map((intern) => (
                  <Link key={intern.id} to={`/users/${intern.id}`} className="directory-card">
                    <div className="directory-card__head">
                      <strong>{intern.name}</strong>
                      <span>{intern.intern_id}</span>
                    </div>
                    <p>{intern.education}</p>
                    <ReviewSummaryCard reviewSummary={intern.review_summary} />
                  </Link>
                ))}
              </div>
            </Panel>

            <Panel title="Recent activity" subtitle="A live operational snapshot">
              <div className="timeline">
                {data.recent_activity?.map((activity, index) => (
                  <article key={`${activity.activity_type}-${index}`} className="timeline__item">
                    <div className="timeline__dot" />
                    <div>
                      <strong>{activity.title}</strong>
                      <p>{activity.message}</p>
                      <span>{formatDate(activity.timestamp)}</span>
                    </div>
                  </article>
                ))}
              </div>
            </Panel>
          </div>

          <div className="two-column">
            <Panel
              title="Pending approvals"
              subtitle="Requests needing attention"
              action={<Link className="text-link" to="/approvals">Manage approvals</Link>}
            >
              <div className="list-stack">
                {data.pending_approvals?.map((approval) => (
                  <article key={approval.id} className="entity-card">
                    <div className="entity-card__top">
                      <div>
                        <strong>{approval.requester_name}</strong>
                        <span>{titleCase(approval.request_type)} request</span>
                      </div>
                      <span className={`status-pill status-pill--${approval.status}`}>{titleCase(approval.status)}</span>
                    </div>
                    <p>{approval.reason}</p>
                  </article>
                ))}
              </div>
            </Panel>

            <Panel
              title={data.role === "admin" ? "Recent reviews" : "Recent reviews given"}
              subtitle="Manager feedback and intern ranking signals"
              action={<Link className="text-link" to="/reviews">Open reviews</Link>}
            >
              <div className="list-stack">
                {(data.recent_reviews || data.recent_reviews_given || []).map((review) => (
                  <article key={review.id} className="entity-card">
                    <div className="entity-card__top">
                      <div>
                        <strong>{review.intern_name}</strong>
                        <span>{review.manager_name}</span>
                      </div>
                      <RatingStars value={review.average_rating} />
                    </div>
                    <p>{review.communication_comment || review.technical_comment}</p>
                  </article>
                ))}
              </div>
            </Panel>
          </div>
        </>
      )}
    </div>
  );
}
