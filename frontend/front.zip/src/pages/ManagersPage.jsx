export function ManagersPage() {
  return <div className="page-stack"><div className="state-block"><h2>Welcome to Manager Profiles</h2><p>This page is under construction.</p></div></div>;
}
