export function PerformancePage() {
  return <div className="page-stack"><div className="state-block"><h2>Welcome to Performance</h2><p>This page is under construction.</p></div></div>;
}
